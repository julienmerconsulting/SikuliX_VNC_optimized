"""
Notes persistees sur tests (triage collaboratif).

Stockage : `.pytest_translate/notes.json` a la racine du projet.
Structure :
    {
      "tests/test_login.py::test_auth": {
        "note": "Flaky since 15/04, see TICKET-234",
        "updated": "2026-04-20T10:30:00Z"
      }
    }

Edition : via CLI uniquement (le rapport HTML est statique, ne peut pas
ecrire sur le disque).

Commandes :
    pytest-translate-note set <nodeid> "<texte>"
    pytest-translate-note get <nodeid>
    pytest-translate-note rm <nodeid>
    pytest-translate-note list
"""

from __future__ import annotations

import json
import time
from pathlib import Path


NOTES_DIR = ".pytest_translate"
NOTES_FILE = "notes.json"


def _resolve_path(root: Path | None = None) -> Path:
    """Retourne le chemin absolu du fichier notes.json (cree les parents)."""
    base = root or Path.cwd()
    notes_dir = base / NOTES_DIR
    notes_dir.mkdir(parents=True, exist_ok=True)
    return notes_dir / NOTES_FILE


def load_notes(root: Path | None = None) -> dict[str, dict]:
    """Charge les notes depuis le disque. Retourne {} si fichier absent/corrompu."""
    path = _resolve_path(root)
    if not path.exists():
        return {}
    try:
        return json.loads(path.read_text(encoding="utf-8"))
    except (json.JSONDecodeError, OSError):
        return {}


def save_notes(notes: dict[str, dict], root: Path | None = None) -> None:
    """Sauvegarde les notes sur le disque (indent=2, UTF-8)."""
    path = _resolve_path(root)
    path.write_text(
        json.dumps(notes, ensure_ascii=False, indent=2, sort_keys=True),
        encoding="utf-8",
    )


def set_note(nodeid: str, text: str, root: Path | None = None) -> None:
    """Ajoute ou met a jour une note sur un test."""
    notes = load_notes(root)
    notes[nodeid] = {
        "note": text,
        "updated": time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime()),
    }
    save_notes(notes, root)


def get_note(nodeid: str, root: Path | None = None) -> dict | None:
    """Retourne la note d'un test ou None si absent."""
    return load_notes(root).get(nodeid)


def remove_note(nodeid: str, root: Path | None = None) -> bool:
    """Supprime la note. Retourne True si quelque chose a ete supprime."""
    notes = load_notes(root)
    if nodeid in notes:
        del notes[nodeid]
        save_notes(notes, root)
        return True
    return False


def list_notes(root: Path | None = None) -> dict[str, dict]:
    """Retourne toutes les notes."""
    return load_notes(root)


# --------------------------------------------------------------------------
# CLI entry point
# --------------------------------------------------------------------------


def main() -> int:
    import sys

    argv = sys.argv[1:]
    if not argv or argv[0] in ("-h", "--help", "help"):
        print(__doc__)
        return 0

    cmd = argv[0]

    if cmd == "set":
        if len(argv) < 3:
            print("usage: pytest-translate-note set <nodeid> <text>")
            return 2
        nodeid = argv[1]
        text = " ".join(argv[2:])
        set_note(nodeid, text)
        print(f"note set on {nodeid}")
        return 0

    if cmd == "get":
        if len(argv) < 2:
            print("usage: pytest-translate-note get <nodeid>")
            return 2
        nodeid = argv[1]
        note = get_note(nodeid)
        if note is None:
            print(f"no note for {nodeid}")
            return 1
        print(f"{nodeid}")
        print(f"  [{note['updated']}] {note['note']}")
        return 0

    if cmd in ("rm", "remove", "delete"):
        if len(argv) < 2:
            print("usage: pytest-translate-note rm <nodeid>")
            return 2
        nodeid = argv[1]
        if remove_note(nodeid):
            print(f"note removed from {nodeid}")
            return 0
        print(f"no note for {nodeid}")
        return 1

    if cmd in ("list", "ls"):
        notes = list_notes()
        if not notes:
            print("(no notes)")
            return 0
        for nodeid, entry in sorted(notes.items()):
            print(f"{nodeid}")
            print(f"  [{entry['updated']}] {entry['note']}")
            print()
        return 0

    print(f"unknown command: {cmd}")
    print(__doc__)
    return 2


if __name__ == "__main__":
    raise SystemExit(main())
