"""Themes additionnels : dracula, high-contrast, solarized.

Chaque theme est un dict de CSS custom properties qui override :root.
Active via attribut data-theme sur <html> (gere par JS).
"""

THEMES = {
    "dracula": {
        "--bg": "#282a36",
        "--bg-soft": "#21222c",
        "--card": "#44475a",
        "--card-hover": "#4d5065",
        "--sidebar": "#21222c",
        "--fg": "#f8f8f2",
        "--fg-soft": "#e2e2dc",
        "--muted": "#6272a4",
        "--border": "#44475a",
        "--code-bg": "#191a21",
        "--accent": "#bd93f9",
        "--c-passed": "#50fa7b",
        "--c-failed": "#ff5555",
        "--c-error": "#ffb86c",
        "--c-skipped": "#f1fa8c",
        "--c-xfailed": "#bd93f9",
        "--c-xpassed": "#8be9fd",
    },
    "high-contrast": {
        "--bg": "#000000",
        "--bg-soft": "#0a0a0a",
        "--card": "#1a1a1a",
        "--card-hover": "#2a2a2a",
        "--sidebar": "#000000",
        "--fg": "#ffffff",
        "--fg-soft": "#e0e0e0",
        "--muted": "#a0a0a0",
        "--border": "#ffffff",
        "--code-bg": "#0a0a0a",
        "--accent": "#ffff00",
        "--c-passed": "#00ff00",
        "--c-failed": "#ff0000",
        "--c-error": "#ff8800",
        "--c-skipped": "#ffff00",
        "--c-xfailed": "#ff00ff",
        "--c-xpassed": "#00ffff",
    },
    "solarized": {
        "--bg": "#fdf6e3",
        "--bg-soft": "#eee8d5",
        "--card": "#fdf6e3",
        "--card-hover": "#eee8d5",
        "--sidebar": "#eee8d5",
        "--fg": "#073642",
        "--fg-soft": "#586e75",
        "--muted": "#93a1a1",
        "--border": "#d3cdbb",
        "--code-bg": "#eee8d5",
        "--accent": "#268bd2",
        "--c-passed": "#859900",
        "--c-failed": "#dc322f",
        "--c-error": "#cb4b16",
        "--c-skipped": "#b58900",
        "--c-xfailed": "#6c71c4",
        "--c-xpassed": "#2aa198",
    },
}


def render_theme_css() -> str:
    """Genere les blocs CSS [data-theme="X"] { ... } pour chaque theme."""
    blocks = []
    for name, vars in THEMES.items():
        kv = "\n  ".join(f"{k}: {v};" for k, v in vars.items())
        blocks.append(f'[data-theme="{name}"] {{\n  {kv}\n}}')
    return "\n\n".join(blocks)
