"""Script client-side : filtres, recherche, toggle details, nav sidebar."""

JS = r"""
(function() {
  'use strict';

  const state = {
    filters: new Set(),
    search: '',
  };

  // Initialise les filtres avec tous les outcomes presents (via legend items)
  document.querySelectorAll('.legend-item[data-outcome]').forEach(function(s) {
    state.filters.add(s.dataset.outcome);
  });

  function matches(test) {
    if (!state.filters.has(test.dataset.outcome)) return false;
    if (state.search) {
      const hay = (test.dataset.nodeid || '').toLowerCase();
      if (!hay.includes(state.search)) return false;
    }
    return true;
  }

  function apply() {
    let visible = 0;
    document.querySelectorAll('.test').forEach(function(t) {
      const show = matches(t);
      t.style.display = show ? '' : 'none';
      if (show) visible++;
    });
    const empty = document.querySelector('.empty-filter');
    if (empty) empty.style.display = visible === 0 ? '' : 'none';
    const counter = document.querySelector('[data-visible-counter]');
    if (counter) counter.textContent = visible;
  }

  function refreshLegendClasses() {
    document.querySelectorAll('.legend-item[data-outcome]').forEach(function(l) {
      if (state.filters.has(l.dataset.outcome)) l.classList.remove('off');
      else l.classList.add('off');
    });
  }

  // Global : appele depuis les liens sidebar "filterOnly('failed')"
  window.filterOnly = function(outcome) {
    state.filters.clear();
    state.filters.add(outcome);
    refreshLegendClasses();
    apply();
    // Scroll vers la zone tests
    const anchor = document.getElementById('tests');
    if (anchor) anchor.scrollIntoView({ behavior: 'smooth' });
    return false;
  };

  // Toggle filter sur legend
  document.querySelectorAll('.legend-item[data-outcome]').forEach(function(l) {
    l.addEventListener('click', function() {
      const o = l.dataset.outcome;
      if (state.filters.has(o)) state.filters.delete(o);
      else state.filters.add(o);
      refreshLegendClasses();
      apply();
    });
  });

  // Toggle detail du test
  document.querySelectorAll('.test-header').forEach(function(h) {
    h.addEventListener('click', function() {
      h.parentElement.classList.toggle('open');
    });
    h.addEventListener('keydown', function(ev) {
      if (ev.key === 'Enter' || ev.key === ' ') {
        ev.preventDefault();
        h.parentElement.classList.toggle('open');
      }
    });
    h.setAttribute('tabindex', '0');
    h.setAttribute('role', 'button');
  });

  // Recherche
  const search = document.querySelector('#search');
  if (search) {
    search.addEventListener('input', function() {
      state.search = search.value.trim().toLowerCase();
      apply();
    });
  }

  // Expand / Collapse all
  const expandBtn = document.querySelector('#expand-all');
  if (expandBtn) expandBtn.addEventListener('click', function() {
    document.querySelectorAll('.test').forEach(function(t) { t.classList.add('open'); });
  });
  const collapseBtn = document.querySelector('#collapse-all');
  if (collapseBtn) collapseBtn.addEventListener('click', function() {
    document.querySelectorAll('.test').forEach(function(t) { t.classList.remove('open'); });
  });

  // Ouverture auto des tests echoues
  const autoOpenFailed = document.body.dataset.autoOpenFailed;
  if (autoOpenFailed === '1') {
    document.querySelectorAll('.test[data-outcome="failed"], .test[data-outcome="error"]').forEach(function(t) {
      t.classList.add('open');
    });
  }

  // Nav sidebar : active l'item selon l'ancre
  const navLinks = document.querySelectorAll('.sidebar-nav a[href^="#"]');
  navLinks.forEach(function(a) {
    a.addEventListener('click', function() {
      navLinks.forEach(function(x) { x.classList.remove('active'); });
      a.classList.add('active');
    });
  });

  // Raccourci / = focus search
  document.addEventListener('keydown', function(ev) {
    if (ev.key === '/' && document.activeElement.tagName !== 'INPUT') {
      ev.preventDefault();
      if (search) search.focus();
    }
  });

  // Theme selector (persiste via localStorage)
  const themeSelect = document.querySelector('#theme-select');
  const THEME_KEY = 'pytest-translate-theme';
  function applyTheme(theme) {
    if (!theme || theme === 'auto') {
      document.documentElement.removeAttribute('data-theme');
    } else {
      document.documentElement.setAttribute('data-theme', theme);
    }
  }
  const savedTheme = localStorage.getItem(THEME_KEY) || 'auto';
  applyTheme(savedTheme);
  if (themeSelect) {
    themeSelect.value = savedTheme;
    themeSelect.addEventListener('change', function() {
      localStorage.setItem(THEME_KEY, themeSelect.value);
      applyTheme(themeSelect.value);
    });
  }

  // Ouvre automatiquement le test lie en hash
  if (location.hash) {
    const target = document.querySelector(location.hash);
    if (target && target.classList.contains('test')) {
      target.classList.add('open');
    }
  }

  apply();
  refreshLegendClasses();
})();
"""
