"""Outputs additionnels : JSON brut + JUnit XML (standard CI)."""

from __future__ import annotations

import json
import time
from pathlib import Path
from xml.sax.saxutils import escape as xml_escape

from .data import ReportData


def export_json(data: ReportData, path: Path) -> None:
    """Exporte le ReportData complet en JSON (pour pipelines custom)."""
    payload = {
        "schema": "pytest-translate/1",
        "started_at": data.started_at,
        "finished_at": data.finished_at,
        "duration": data.duration,
        "total": data.total,
        "success_rate": data.success_rate,
        "counts": dict(data.counts),
        "lang": data.lang,
        "rootdir": data.rootdir,
        "python_version": data.python_version,
        "pytest_version": data.pytest_version,
        "plugin_version": data.plugin_version,
        "platform": data.platform,
        "records": [
            {
                "nodeid": r.nodeid,
                "outcome": r.outcome,
                "duration": r.duration,
                "longrepr": r.longrepr,
                "captured_stdout": r.captured_stdout,
                "captured_stderr": r.captured_stderr,
                "captured_log": r.captured_log,
                "markers": r.markers,
                "start_time": r.start_time,
                "end_time": r.end_time,
            }
            for r in data.records
        ],
    }
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(payload, ensure_ascii=False, indent=2), encoding="utf-8")


def export_junit(data: ReportData, path: Path) -> None:
    """Exporte en JUnit XML (format standard : Jenkins/GitLab/Azure).

    On genere un seul <testsuite> avec tous les tests. Les tests echoues
    incluent <failure> et les erreurs <error>. Les skipped incluent <skipped>.
    """
    counts = data.counts
    failures = counts.get("failed", 0)
    errors = counts.get("error", 0)
    skipped = counts.get("skipped", 0)
    total = data.total

    parts = []
    parts.append('<?xml version="1.0" encoding="UTF-8"?>')
    parts.append(
        f'<testsuite name="pytest-translate" '
        f'tests="{total}" failures="{failures}" errors="{errors}" '
        f'skipped="{skipped}" time="{data.duration:.3f}" '
        f'timestamp="{time.strftime("%Y-%m-%dT%H:%M:%S", time.gmtime(data.started_at))}">'
    )

    for r in data.records:
        classname, testname = _split_nodeid(r.nodeid)
        parts.append(
            f'  <testcase classname="{xml_escape(classname)}" '
            f'name="{xml_escape(testname)}" '
            f'time="{r.duration:.3f}">'
        )
        if r.outcome in ("failed", "xfailed"):
            parts.append(
                f'    <failure message="assertion failed" type="AssertionError">'
                f"<![CDATA[{r.longrepr}]]>"
                f"</failure>"
            )
        elif r.outcome == "error":
            parts.append(
                f'    <error message="error" type="Exception">'
                f"<![CDATA[{r.longrepr}]]>"
                f"</error>"
            )
        elif r.outcome == "skipped":
            parts.append("    <skipped/>")
        if r.captured_stdout:
            parts.append(
                f"    <system-out><![CDATA[{r.captured_stdout}]]></system-out>"
            )
        if r.captured_stderr:
            parts.append(
                f"    <system-err><![CDATA[{r.captured_stderr}]]></system-err>"
            )
        parts.append("  </testcase>")

    parts.append("</testsuite>")

    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text("\n".join(parts), encoding="utf-8")


def _split_nodeid(nodeid: str) -> tuple[str, str]:
    """Separe en classname (path) + testname pour JUnit."""
    if "::" not in nodeid:
        return nodeid, nodeid
    parts = nodeid.split("::")
    return "::".join(parts[:-1]), parts[-1]
