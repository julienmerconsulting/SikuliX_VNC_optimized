"""
Historique multi-run : stocke les 20 derniers runs en JSON local.

Stockage : `.pytest_translate/history.json` a la racine du projet.
Structure :
    {
      "runs": [
        {
          "timestamp": "2026-04-20T10:30:00Z",
          "duration": 2.5,
          "total": 11,
          "counts": {"passed": 7, "failed": 1, ...},
          "outcomes": {"tests/test_x.py::test_a": "passed", ...}
        },
        ...  # plus recent en premier
      ]
    }

Utile pour :
- Detection flaky (test qui change d'outcome entre runs)
- Diff vs previous run ("3 tests verts hier sont rouges maintenant")
- Graphique de trends (pass rate historique)
"""

from __future__ import annotations

import json
import time
from pathlib import Path

from .data import ReportData


HISTORY_DIR = ".pytest_translate"
HISTORY_FILE = "history.json"
MAX_RUNS = 20  # on garde les 20 derniers


def _history_path(root: Path | None = None) -> Path:
    base = root or Path.cwd()
    d = base / HISTORY_DIR
    d.mkdir(parents=True, exist_ok=True)
    return d / HISTORY_FILE


def load_history(root: Path | None = None) -> list[dict]:
    """Retourne la liste des runs (plus recent en premier). Vide si absent/corrompu."""
    path = _history_path(root)
    if not path.exists():
        return []
    try:
        data = json.loads(path.read_text(encoding="utf-8"))
        return data.get("runs", [])
    except (json.JSONDecodeError, OSError):
        return []


def save_run(data: ReportData, root: Path | None = None) -> None:
    """Ajoute le run actuel au debut de l'historique, tronque a MAX_RUNS."""
    history = load_history(root)

    run_entry = {
        "timestamp": time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime(data.finished_at)),
        "duration": round(data.duration, 3),
        "total": data.total,
        "success_rate": round(data.success_rate, 1),
        "counts": dict(data.counts),
        "outcomes": {r.nodeid: r.outcome for r in data.records},
    }

    history.insert(0, run_entry)
    history = history[:MAX_RUNS]

    path = _history_path(root)
    path.write_text(
        json.dumps({"runs": history}, ensure_ascii=False, indent=2),
        encoding="utf-8",
    )


def flaky_score(history: list[dict]) -> dict[str, float]:
    """
    Calcule un score de flakiness par nodeid sur l'historique.

    Score = fraction de runs ou le test a change d'outcome vs le plus recent.
    0.0 = toujours le meme outcome (stable).
    1.0 = toujours different (super flaky, improbable).
    0.5 = instable, change une fois sur deux.

    Ne compte que les tests qui apparaissent dans >= 3 runs.
    """
    if len(history) < 3:
        return {}

    # Collecte les outcomes par nodeid sur tout l'historique
    outcomes_by_nodeid: dict[str, list[str]] = {}
    for run in history:
        for nodeid, outcome in run.get("outcomes", {}).items():
            outcomes_by_nodeid.setdefault(nodeid, []).append(outcome)

    scores = {}
    for nodeid, outcomes in outcomes_by_nodeid.items():
        if len(outcomes) < 3:
            continue
        # Nombre de transitions (changements entre runs consecutifs)
        transitions = sum(
            1 for i in range(1, len(outcomes)) if outcomes[i] != outcomes[i - 1]
        )
        score = transitions / (len(outcomes) - 1)
        if score > 0:
            scores[nodeid] = round(score, 2)
    return scores


def diff_vs_previous(data: ReportData, history: list[dict]) -> dict:
    """
    Compare le run actuel vs le run precedent.

    Retourne :
      {
        "new_failures": [...],    # tests verts avant, rouges maintenant
        "fixed": [...],           # tests rouges avant, verts maintenant
        "still_failing": [...],
        "new_tests": [...],
        "removed_tests": [...],
      }

    Si pas de run precedent, retourne les keys vides.
    """
    empty = {
        "new_failures": [],
        "fixed": [],
        "still_failing": [],
        "new_tests": [],
        "removed_tests": [],
    }
    if not history:
        return empty

    prev = history[0]
    prev_outcomes = prev.get("outcomes", {})
    curr_outcomes = {r.nodeid: r.outcome for r in data.records}

    failing = {"failed", "error"}

    new_failures = []
    fixed = []
    still_failing = []

    for nodeid, curr in curr_outcomes.items():
        prev_outcome = prev_outcomes.get(nodeid)
        if prev_outcome is None:
            continue
        was_failing = prev_outcome in failing
        now_failing = curr in failing
        if not was_failing and now_failing:
            new_failures.append(nodeid)
        elif was_failing and not now_failing:
            fixed.append(nodeid)
        elif was_failing and now_failing:
            still_failing.append(nodeid)

    new_tests = [nid for nid in curr_outcomes if nid not in prev_outcomes]
    removed_tests = [nid for nid in prev_outcomes if nid not in curr_outcomes]

    return {
        "new_failures": sorted(new_failures),
        "fixed": sorted(fixed),
        "still_failing": sorted(still_failing),
        "new_tests": sorted(new_tests),
        "removed_tests": sorted(removed_tests),
    }
