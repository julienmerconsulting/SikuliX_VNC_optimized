"""
Detection auto des screenshots Playwright/Selenium.

Cherche dans :
- ./screenshots/
- ./test-results/
- ./playwright-report/

Associe les images aux tests par matching du nodeid dans le nom de fichier.
"""

from __future__ import annotations

import re
from pathlib import Path


SEARCH_DIRS = ("screenshots", "test-results", "playwright-report", "artifacts")
IMAGE_EXTS = {".png", ".jpg", ".jpeg", ".gif", ".webp"}


def find_screenshots(root: Path | None = None) -> dict[str, list[Path]]:
    """
    Scanne les dossiers courants pour trouver des screenshots.
    Retourne un dict {nodeid: [list of image paths]}.

    Les fichiers sont associes par nom : si le nom contient un nodeid
    (apres normalisation des separateurs), on rattache.
    """
    base = root or Path.cwd()
    images: list[Path] = []
    for d in SEARCH_DIRS:
        p = base / d
        if not p.exists():
            continue
        for img in p.rglob("*"):
            if img.is_file() and img.suffix.lower() in IMAGE_EXTS:
                images.append(img)
    return {"_all": images}


def match_screenshots(records, images: list[Path]) -> dict[str, list[Path]]:
    """
    Associe les screenshots aux tests en matchant le nom de fichier.
    Les nodeids sont normalises (slashes -> underscores) pour la comparaison.
    """
    result: dict[str, list[Path]] = {}
    for img in images:
        name = img.stem.lower()
        for r in records:
            normalized = re.sub(r"[^a-z0-9]+", "_", r.nodeid.lower())
            # On cherche un bout significatif du nodeid dans le nom
            test_name = r.nodeid.split("::")[-1].lower()
            if normalized in name or name in normalized or test_name in name:
                result.setdefault(r.nodeid, []).append(img)
                break
    return result


def encode_as_data_uri(path: Path) -> str:
    """Encode une image en data URI pour embed dans HTML self-contained."""
    import base64

    data = path.read_bytes()
    ext = path.suffix.lower().lstrip(".")
    if ext == "jpg":
        ext = "jpeg"
    b64 = base64.b64encode(data).decode("ascii")
    return f"data:image/{ext};base64,{b64}"
