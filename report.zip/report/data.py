"""Data model du reporter : TestRecord, ReportData."""

from __future__ import annotations

import platform
import sys
import time
from dataclasses import dataclass, field


@dataclass
class TestRecord:
    """Un test : resultat agrege des 3 phases (setup, call, teardown)."""

    nodeid: str
    outcome: str = "passed"  # passed, failed, skipped, xfailed, xpassed, error
    duration: float = 0.0
    longrepr: str = ""
    captured_stdout: str = ""
    captured_stderr: str = ""
    captured_log: str = ""
    error_message: str = ""
    when: str = "call"
    markers: list[str] = field(default_factory=list)
    start_time: float = 0.0
    end_time: float = 0.0

    @property
    def file(self) -> str:
        return self.nodeid.split("::")[0] if "::" in self.nodeid else self.nodeid

    @property
    def name(self) -> str:
        parts = self.nodeid.split("::")
        return parts[-1] if len(parts) > 1 else self.nodeid

    @property
    def has_details(self) -> bool:
        return bool(
            self.longrepr
            or self.captured_stdout
            or self.captured_stderr
            or self.captured_log
        )


@dataclass
class ReportData:
    """Snapshot complet d'une session pytest."""

    started_at: float = field(default_factory=time.time)
    finished_at: float = 0.0
    records: list[TestRecord] = field(default_factory=list)
    rootdir: str = ""
    python_version: str = field(
        default_factory=lambda: ".".join(map(str, sys.version_info[:3]))
    )
    pytest_version: str = ""
    plugin_version: str = ""
    platform: str = field(default_factory=platform.platform)
    lang: str = "en"

    @property
    def duration(self) -> float:
        if self.finished_at <= 0:
            return 0.0
        return max(0.0, self.finished_at - self.started_at)

    @property
    def counts(self) -> dict[str, int]:
        out: dict[str, int] = {}
        for r in self.records:
            out[r.outcome] = out.get(r.outcome, 0) + 1
        return out

    @property
    def total(self) -> int:
        return len(self.records)

    @property
    def success_rate(self) -> float:
        """Pourcentage de tests passes (0.0 - 100.0)."""
        if not self.records:
            return 0.0
        passed = self.counts.get("passed", 0) + self.counts.get("xpassed", 0)
        return 100.0 * passed / self.total
