"""Hooks pytest pour collecter les resultats en vue du reporter HTML."""

from __future__ import annotations

import time

from .data import ReportData, TestRecord


class Collector:
    """Agrege les reports pytest_runtest_logreport en TestRecord par nodeid."""

    def __init__(self, data: ReportData):
        self.data = data
        self._by_nodeid: dict[str, TestRecord] = {}

    def capture(self, report):
        """Appele depuis pytest_runtest_logreport pour chaque phase."""
        nodeid = report.nodeid
        rec = self._by_nodeid.get(nodeid)
        if rec is None:
            rec = TestRecord(nodeid=nodeid, markers=self._extract_markers(report))
            self._by_nodeid[nodeid] = rec
            self.data.records.append(rec)

        rec.duration += getattr(report, "duration", 0.0)

        if report.when == "setup" and rec.start_time == 0.0:
            rec.start_time = getattr(report, "start", time.time())

        if report.when == "teardown":
            rec.end_time = getattr(report, "stop", time.time())

        # Mise a jour outcome : la regle est "le plus grave gagne"
        new_outcome = self._resolve_outcome(report, rec.outcome)
        if new_outcome:
            rec.outcome = new_outcome
            rec.when = report.when

        # Capture : stdout / stderr / log via report.sections (liste de tuples)
        for section_name, section_text in getattr(report, "sections", []) or []:
            lowered = section_name.lower()
            if "stdout" in lowered:
                rec.captured_stdout += section_text
            elif "stderr" in lowered:
                rec.captured_stderr += section_text
            elif "log" in lowered:
                rec.captured_log += section_text

        # longrepr = traceback ou message d'erreur
        if getattr(report, "longrepr", None) and not rec.longrepr:
            rec.longrepr = str(report.longrepr)

    @staticmethod
    def _extract_markers(report) -> list[str]:
        # Les keywords pytest incluent les markers (dict nodeid -> True)
        keywords = getattr(report, "keywords", {}) or {}
        standard_keywords = {"parametrize", "pytestmark"}
        return [
            k
            for k in keywords
            if k not in standard_keywords
            and not k.startswith("test_")
            and "[" not in k
            and "::" not in k
            and "." not in k
            and k not in ("", "True", "False")
        ]

    @staticmethod
    def _resolve_outcome(report, current: str) -> str:
        """Retourne le nouvel outcome a retenir selon la phase et le precedent."""
        # XFAIL / XPASS : wasxfail est set par le marker xfail
        if hasattr(report, "wasxfail"):
            if report.skipped:
                return "xfailed"
            if report.passed:
                return "xpassed"

        # Erreur en setup ou teardown = ERROR (prioritaire sur call)
        if report.when in ("setup", "teardown") and report.failed:
            return "error"

        # Call phase : pass / fail / skipped
        if report.when == "call":
            if report.failed:
                return "failed"
            if report.skipped:
                return "skipped"
            if report.passed:
                return "passed"

        # Skip en setup (@pytest.mark.skip)
        if report.when == "setup" and report.skipped:
            return "skipped"

        # Sinon on garde l'existant (ne regresse pas)
        return ""
