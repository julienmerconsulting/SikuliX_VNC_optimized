"""Feuille de style du reporter. Layout Allure-hybrid : sidebar + donut + cards."""

CSS = r"""
:root {
  color-scheme: light dark;
  --bg: #ffffff;
  --bg-soft: #f8fafc;
  --card: #ffffff;
  --card-hover: #f1f5f9;
  --sidebar: #f8fafc;
  --fg: #0f172a;
  --fg-soft: #334155;
  --muted: #64748b;
  --border: #e2e8f0;
  --code-bg: #f1f5f9;
  --accent: #6366f1;
  --shadow: 0 1px 3px rgba(0,0,0,0.05), 0 1px 2px rgba(0,0,0,0.03);
  --shadow-lg: 0 10px 30px rgba(0,0,0,0.08);

  --c-passed: #22c55e;
  --c-failed: #ef4444;
  --c-error: #f97316;
  --c-skipped: #f59e0b;
  --c-xfailed: #a855f7;
  --c-xpassed: #06b6d4;
  --c-passed-soft: rgba(34,197,94,0.15);
  --c-failed-soft: rgba(239,68,68,0.15);
}
@media (prefers-color-scheme: dark) {
  :root {
    --bg: #0b1120;
    --bg-soft: #0f172a;
    --card: #111827;
    --card-hover: #1f2937;
    --sidebar: #0a0f1c;
    --fg: #f1f5f9;
    --fg-soft: #cbd5e1;
    --muted: #94a3b8;
    --border: #1e293b;
    --code-bg: #020617;
    --accent: #818cf8;
    --shadow: 0 1px 3px rgba(0,0,0,0.3), 0 1px 2px rgba(0,0,0,0.2);
    --shadow-lg: 0 10px 30px rgba(0,0,0,0.4);
  }
}
* { box-sizing: border-box; }
html { scroll-behavior: smooth; }
body {
  margin: 0;
  padding: 0;
  font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, 'Helvetica Neue', sans-serif;
  background: var(--bg);
  color: var(--fg);
  line-height: 1.5;
  -webkit-font-smoothing: antialiased;
  min-height: 100vh;
}
code, pre, .mono { font-family: ui-monospace, 'SF Mono', 'Cascadia Code', Menlo, monospace; }

/* ===== Layout ===== */
.layout {
  display: grid;
  grid-template-columns: 240px 1fr;
  min-height: 100vh;
}
.sidebar {
  background: var(--sidebar);
  border-right: 1px solid var(--border);
  padding: 1.5rem 0.75rem;
  position: sticky;
  top: 0;
  height: 100vh;
  overflow-y: auto;
}
.sidebar-brand {
  padding: 0 0.75rem 1.5rem;
  border-bottom: 1px solid var(--border);
  margin-bottom: 1rem;
}
.sidebar-brand h1 {
  margin: 0;
  font-size: 1rem;
  font-weight: 700;
  letter-spacing: -0.01em;
  color: var(--fg);
}
.sidebar-brand .tagline {
  font-size: 0.72rem;
  color: var(--muted);
  margin-top: 0.2rem;
  display: block;
}
.sidebar-section-title {
  font-size: 0.68rem;
  color: var(--muted);
  text-transform: uppercase;
  letter-spacing: 0.1em;
  margin: 1rem 0.75rem 0.4rem;
  font-weight: 600;
}
.sidebar-nav {
  list-style: none;
  margin: 0;
  padding: 0;
}
.sidebar-nav li a {
  display: flex;
  align-items: center;
  justify-content: space-between;
  padding: 0.5rem 0.75rem;
  border-radius: 6px;
  color: var(--fg-soft);
  text-decoration: none;
  font-size: 0.88rem;
  margin-bottom: 0.15rem;
  transition: background 0.1s;
}
.sidebar-nav li a:hover { background: var(--card-hover); color: var(--fg); }
.sidebar-nav li a.active { background: var(--accent); color: white; }
.sidebar-nav .nav-count {
  background: var(--bg);
  color: var(--muted);
  border-radius: 999px;
  padding: 0.05rem 0.5rem;
  font-size: 0.72rem;
  font-weight: 600;
  min-width: 22px;
  text-align: center;
}
.sidebar-nav li a.active .nav-count { background: rgba(255,255,255,0.25); color: white; }
.main {
  padding: 2rem 2rem 4rem;
  max-width: 1100px;
  width: 100%;
}
@media (max-width: 900px) {
  .layout { grid-template-columns: 1fr; }
  .sidebar {
    position: static;
    height: auto;
    border-right: none;
    border-bottom: 1px solid var(--border);
  }
  .sidebar-nav { display: flex; flex-wrap: wrap; gap: 0.25rem; }
  .sidebar-nav li { flex: 0 0 auto; }
  .sidebar-section-title { display: none; }
  .main { padding: 1.25rem; }
}

/* ===== Header + overview ===== */
.page-header { margin-bottom: 2rem; }
.page-header h2 { margin: 0 0 0.3rem; font-size: 1.75rem; font-weight: 700; letter-spacing: -0.02em; }
.page-header .subtitle { color: var(--muted); font-size: 0.9rem; }

/* Overview split : donut + stats side-by-side */
.overview {
  display: grid;
  grid-template-columns: auto 1fr;
  gap: 2rem;
  align-items: center;
  background: var(--card);
  border: 1px solid var(--border);
  border-radius: 12px;
  padding: 1.75rem;
  margin-bottom: 1.5rem;
  box-shadow: var(--shadow);
}
@media (max-width: 640px) {
  .overview { grid-template-columns: 1fr; text-align: center; }
}
.donut-wrap {
  position: relative;
  width: 180px;
  height: 180px;
}
.donut-wrap svg {
  width: 100%;
  height: 100%;
  transform: rotate(-90deg);
}
.donut-wrap svg circle {
  fill: none;
  stroke-width: 18;
  stroke-linecap: butt;
}
.donut-center {
  position: absolute;
  top: 50%; left: 50%;
  transform: translate(-50%, -50%);
  text-align: center;
  pointer-events: none;
}
.donut-center .big {
  font-size: 2rem;
  font-weight: 700;
  color: var(--fg);
  line-height: 1;
}
.donut-center .label {
  font-size: 0.7rem;
  color: var(--muted);
  text-transform: uppercase;
  letter-spacing: 0.08em;
  margin-top: 0.3rem;
}
.legend { display: grid; grid-template-columns: repeat(auto-fit, minmax(130px, 1fr)); gap: 0.6rem; }
.legend-item {
  display: flex;
  align-items: center;
  gap: 0.5rem;
  cursor: pointer;
  user-select: none;
  padding: 0.5rem 0.65rem;
  border-radius: 6px;
  border: 1px solid var(--border);
  background: var(--bg-soft);
  transition: opacity 0.15s, transform 0.15s;
}
.legend-item:hover { transform: translateY(-1px); }
.legend-item.off { opacity: 0.35; }
.legend-dot {
  width: 10px; height: 10px;
  border-radius: 50%;
  flex-shrink: 0;
}
.legend-label {
  flex: 1;
  font-size: 0.75rem;
  color: var(--muted);
  text-transform: capitalize;
}
.legend-value {
  font-size: 0.85rem;
  font-weight: 700;
  color: var(--fg);
  font-variant-numeric: tabular-nums;
}

/* Summary tiles */
.tiles {
  display: grid;
  grid-template-columns: repeat(auto-fit, minmax(180px, 1fr));
  gap: 0.75rem;
  margin-bottom: 1.5rem;
}
.tile {
  background: var(--card);
  border: 1px solid var(--border);
  border-radius: 10px;
  padding: 1.1rem 1.25rem;
  box-shadow: var(--shadow);
}
.tile .tile-value {
  font-size: 1.75rem;
  font-weight: 700;
  line-height: 1;
  color: var(--fg);
  font-variant-numeric: tabular-nums;
}
.tile .tile-label {
  font-size: 0.72rem;
  color: var(--muted);
  text-transform: uppercase;
  letter-spacing: 0.08em;
  margin-top: 0.4rem;
}
.tile.accent .tile-value { color: var(--accent); }

/* ===== Meta panel ===== */
.meta {
  background: var(--card);
  border: 1px solid var(--border);
  border-radius: 10px;
  padding: 1rem 1.25rem;
  margin-bottom: 1.5rem;
  font-size: 0.85rem;
  box-shadow: var(--shadow);
  display: grid;
  grid-template-columns: repeat(auto-fit, minmax(220px, 1fr));
  gap: 0.5rem 1.5rem;
}
.meta-key { color: var(--muted); margin-right: 0.5rem; }
.meta-val { color: var(--fg-soft); font-family: inherit; }

/* ===== Section titles ===== */
.section-title {
  display: flex;
  align-items: center;
  justify-content: space-between;
  margin: 2rem 0 1rem;
}
.section-title h3 { margin: 0; font-size: 1.2rem; font-weight: 600; }
.section-title .subtitle { color: var(--muted); font-size: 0.85rem; }

/* ===== Tests list ===== */
.tests { display: flex; flex-direction: column; gap: 0.5rem; }
.test {
  background: var(--card);
  border: 1px solid var(--border);
  border-left: 4px solid var(--test-accent, var(--border));
  border-radius: 8px;
  overflow: hidden;
  box-shadow: var(--shadow);
  transition: box-shadow 0.15s;
  scroll-margin-top: 1rem;
}
.test[data-outcome="passed"]  { --test-accent: var(--c-passed); }
.test[data-outcome="failed"]  { --test-accent: var(--c-failed); }
.test[data-outcome="error"]   { --test-accent: var(--c-error); }
.test[data-outcome="skipped"] { --test-accent: var(--c-skipped); }
.test[data-outcome="xfailed"] { --test-accent: var(--c-xfailed); }
.test[data-outcome="xpassed"] { --test-accent: var(--c-xpassed); }
.test:hover { box-shadow: var(--shadow-lg); }
.test-header {
  padding: 0.9rem 1.1rem;
  display: flex;
  gap: 0.85rem;
  align-items: center;
  cursor: pointer;
  user-select: none;
}
.test-header:hover { background: var(--card-hover); }
.chevron {
  transition: transform 0.2s;
  color: var(--muted);
  font-size: 0.7rem;
  width: 14px;
  text-align: center;
}
.test.open .chevron { transform: rotate(90deg); }
.badge {
  padding: 0.2rem 0.65rem;
  border-radius: 999px;
  font-size: 0.7rem;
  font-weight: 700;
  letter-spacing: 0.05em;
  color: white;
  background: var(--test-accent, var(--muted));
  text-transform: uppercase;
  flex-shrink: 0;
  min-width: 70px;
  text-align: center;
}
.nodeid { flex: 1; font-size: 0.9rem; word-break: break-all; }
.nodeid .file { color: var(--muted); }
.nodeid .sep { color: var(--muted); margin: 0 0.1rem; }
.nodeid .test-name { font-weight: 600; }
.duration {
  color: var(--muted);
  font-size: 0.8rem;
  font-variant-numeric: tabular-nums;
  flex-shrink: 0;
}
.test-body {
  border-top: 1px solid var(--border);
  display: none;
}
.test.open .test-body { display: block; }
.test-body .section {
  padding: 0.9rem 1.1rem;
  border-bottom: 1px solid var(--border);
}
.test-body .section:last-child { border-bottom: none; }
.test-body h4 {
  margin: 0 0 0.5rem;
  color: var(--muted);
  font-size: 0.7rem;
  font-weight: 600;
  letter-spacing: 0.08em;
  text-transform: uppercase;
}
.test-body pre {
  margin: 0;
  padding: 0.75rem 1rem;
  background: var(--code-bg);
  border-radius: 6px;
  overflow-x: auto;
  font-size: 0.825rem;
  white-space: pre-wrap;
  word-wrap: break-word;
  line-height: 1.45;
}
.markers { display: flex; gap: 0.3rem; flex-wrap: wrap; }
.marker {
  font-size: 0.7rem;
  padding: 0.1rem 0.5rem;
  background: var(--code-bg);
  color: var(--muted);
  border-radius: 4px;
  font-family: inherit;
}

/* ===== Diagnosis section ===== */
.section.diagnosis {
  background: rgba(99, 102, 241, 0.08);
  border-left: 3px solid var(--accent);
}
.section.diagnosis h4 { color: var(--accent); }
.diag-body {
  display: flex;
  flex-direction: column;
  gap: 0.3rem;
}
.diag-kind {
  display: inline-block;
  align-self: flex-start;
  font-size: 0.68rem;
  background: var(--accent);
  color: white;
  padding: 0.1rem 0.55rem;
  border-radius: 4px;
  text-transform: uppercase;
  letter-spacing: 0.08em;
  font-weight: 600;
}
.diag-message {
  font-size: 0.9rem;
  color: var(--fg);
  line-height: 1.5;
}

/* ===== Notes section ===== */
.section.note {
  background: rgba(251, 191, 36, 0.08);
  border-left: 3px solid #fbbf24;
}
.section.note h4 { color: #d97706; }
.note-meta {
  color: var(--muted);
  font-size: 0.7rem;
  margin-bottom: 0.3rem;
}
.note-text {
  font-size: 0.9rem;
  color: var(--fg);
  line-height: 1.5;
  white-space: pre-wrap;
}
.note-indicator {
  font-size: 0.9rem;
  flex-shrink: 0;
  opacity: 0.8;
  margin-left: 0.3rem;
}
.flaky-indicator {
  font-size: 0.95rem;
  flex-shrink: 0;
  color: var(--c-skipped);
  margin-left: 0.3rem;
}

/* ===== Diff panel (vs previous run) ===== */
.diff-panel {
  background: var(--card);
  border: 1px solid var(--border);
  border-radius: 12px;
  padding: 1.5rem;
  margin-bottom: 1.5rem;
  box-shadow: var(--shadow);
}
.diff-panel h3 { margin: 0 0 1rem; font-size: 1.1rem; font-weight: 600; }
.diff-grid {
  display: grid;
  grid-template-columns: repeat(auto-fit, minmax(240px, 1fr));
  gap: 0.75rem;
}
.diff-item {
  padding: 0.85rem 1rem;
  border-radius: 8px;
  border-left: 4px solid var(--border);
  background: var(--bg-soft);
}
.diff-item.diff-regress  { border-left-color: var(--c-failed);  background: var(--c-failed-soft); }
.diff-item.diff-fixed    { border-left-color: var(--c-passed);  background: var(--c-passed-soft); }
.diff-item.diff-still    { border-left-color: var(--c-error); }
.diff-item.diff-new      { border-left-color: var(--c-xpassed); }
.diff-item.diff-removed  { border-left-color: var(--muted); }
.diff-badge {
  font-size: 0.68rem;
  font-weight: 700;
  text-transform: uppercase;
  letter-spacing: 0.08em;
  color: var(--fg);
  display: block;
}
.diff-count {
  display: inline-block;
  font-size: 1.4rem;
  font-weight: 700;
  margin-top: 0.3rem;
  font-variant-numeric: tabular-nums;
}
.diff-list {
  margin: 0.5rem 0 0;
  padding: 0;
  list-style: none;
  font-size: 0.8rem;
  font-family: ui-monospace, monospace;
  color: var(--fg-soft);
  word-break: break-all;
}
.diff-list li { padding: 0.1rem 0; }

/* ===== History sparkline ===== */
.history-panel {
  background: var(--card);
  border: 1px solid var(--border);
  border-radius: 12px;
  padding: 1.25rem;
  margin-bottom: 1.5rem;
  box-shadow: var(--shadow);
}
.history-panel h3 { margin: 0 0 0.85rem; font-size: 1.05rem; font-weight: 600; }
.history-panel .subtitle { color: var(--muted); font-size: 0.8rem; margin-left: 0.5rem; }
.spark-bars {
  display: flex;
  align-items: flex-end;
  gap: 4px;
  height: 50px;
}
.spark-bar {
  flex: 1;
  min-width: 4px;
  height: 100%;
  display: flex;
  flex-direction: column-reverse;
  cursor: help;
  background: var(--bg-soft);
  border-radius: 3px;
  overflow: hidden;
  transition: transform 0.1s;
}
.spark-bar:hover { transform: scaleY(1.05); }
.spark-bar span { display: block; width: 100%; }

/* ===== Exec summary ===== */
.exec-summary {
  background: var(--card);
  border: 1px solid var(--border);
  border-left: 5px solid var(--c-passed);
  border-radius: 10px;
  padding: 1rem 1.25rem;
  margin-bottom: 1.5rem;
  box-shadow: var(--shadow);
}
.exec-summary.exec-alert { border-left-color: var(--c-failed); }
.exec-summary summary {
  cursor: pointer;
  list-style: none;
  display: flex;
  gap: 0.75rem;
  align-items: center;
  font-size: 1rem;
}
.exec-summary summary::-webkit-details-marker { display: none; }
.exec-badge {
  padding: 0.2rem 0.7rem;
  border-radius: 999px;
  font-size: 0.7rem;
  font-weight: 700;
  letter-spacing: 0.08em;
  text-transform: uppercase;
  color: white;
  flex-shrink: 0;
}
.exec-ok-badge { background: var(--c-passed); }
.exec-alert-badge { background: var(--c-failed); }
.exec-main {
  font-size: 0.95rem;
  color: var(--fg);
}
.exec-body {
  margin-top: 0.85rem;
  padding-top: 0.85rem;
  border-top: 1px solid var(--border);
  color: var(--fg-soft);
  font-size: 0.88rem;
}

/* ===== Timeline ===== */
.timeline-panel {
  background: var(--card);
  border: 1px solid var(--border);
  border-radius: 12px;
  padding: 1.25rem;
  margin-bottom: 1.5rem;
  box-shadow: var(--shadow);
}
.timeline-panel h3 { margin: 0 0 0.85rem; font-size: 1.05rem; font-weight: 600; }
.timeline-chart { overflow-x: auto; }

/* ===== Smart stacktrace ===== */
pre.smart-trace .line { display: block; }
pre.smart-trace .line-fw { opacity: 0.55; }
pre.smart-trace .line-user {
  background: rgba(99, 102, 241, 0.08);
  border-radius: 2px;
  padding: 1px 0;
}
pre.smart-trace .line-error {
  color: var(--c-failed);
  font-weight: 600;
}

/* ===== Theme selector ===== */
.theme-selector { padding: 0 0.75rem; }
.theme-selector select {
  width: 100%;
  padding: 0.45rem 0.6rem;
  font-size: 0.85rem;
  background: var(--card);
  color: var(--fg);
  border: 1px solid var(--border);
  border-radius: 6px;
}

/* ===== Permalink button ===== */
.permalink-btn {
  color: var(--muted);
  text-decoration: none;
  font-size: 0.95rem;
  padding: 0.15rem 0.35rem;
  border-radius: 4px;
  opacity: 0;
  transition: opacity 0.15s, background 0.15s;
}
.test-header:hover .permalink-btn { opacity: 1; }
.permalink-btn:hover { background: var(--card-hover); }

/* ===== Screenshots gallery ===== */
.shots {
  display: grid;
  grid-template-columns: repeat(auto-fit, minmax(180px, 1fr));
  gap: 0.6rem;
}
.shot-link {
  display: block;
  border: 1px solid var(--border);
  border-radius: 6px;
  overflow: hidden;
  background: var(--bg-soft);
  text-decoration: none;
  color: var(--fg-soft);
  transition: transform 0.1s;
}
.shot-link:hover { transform: scale(1.02); box-shadow: var(--shadow-lg); }
.shot-link img {
  display: block;
  width: 100%;
  height: 120px;
  object-fit: cover;
}
.shot-name {
  display: block;
  padding: 0.4rem 0.5rem;
  font-size: 0.72rem;
  color: var(--muted);
  word-break: break-all;
}

/* ===== Controls ===== */
.controls {
  display: flex;
  gap: 0.5rem;
  align-items: center;
  margin-bottom: 1rem;
  flex-wrap: wrap;
}
.control-btn {
  background: var(--card);
  color: var(--fg-soft);
  border: 1px solid var(--border);
  border-radius: 6px;
  padding: 0.4rem 0.75rem;
  font-size: 0.8rem;
  cursor: pointer;
  transition: background 0.15s;
}
.control-btn:hover { background: var(--card-hover); }
.search {
  background: var(--card);
  color: var(--fg);
  border: 1px solid var(--border);
  border-radius: 6px;
  padding: 0.4rem 0.75rem;
  font-size: 0.85rem;
  flex: 1;
  min-width: 200px;
}
.search:focus { outline: 2px solid var(--accent); outline-offset: -1px; }

/* ===== Empty ===== */
.empty {
  text-align: center;
  padding: 3rem;
  color: var(--muted);
  border: 1px dashed var(--border);
  border-radius: 10px;
  background: var(--bg-soft);
}

/* ===== Footer ===== */
footer {
  margin-top: 3rem;
  padding-top: 1.5rem;
  border-top: 1px solid var(--border);
  text-align: center;
  color: var(--muted);
  font-size: 0.8rem;
}
footer a { color: var(--accent); text-decoration: none; }

/* ===== Print ===== */
@media print {
  body { background: white; color: black; }
  .sidebar, .controls { display: none !important; }
  .layout { display: block; }
  .main { padding: 0; max-width: 100%; }
  .test-body { display: block !important; }
}

/* Mobile tweaks */
@media (max-width: 640px) {
  .page-header h2 { font-size: 1.4rem; }
  .tiles { grid-template-columns: 1fr 1fr; }
  .tile { padding: 0.9rem; }
  .tile .tile-value { font-size: 1.4rem; }
  .donut-wrap { width: 140px; height: 140px; }
  .donut-center .big { font-size: 1.5rem; }
}
"""
