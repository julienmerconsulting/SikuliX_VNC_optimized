"""
Diagnostic offline des tests echoues : heuristiques pre-cablees, zero IA.

Regles : liste de (regex_pattern, message_key, optional_hint_key).
Le hint est la traduction gettext (multilangue). Les groupes captures par
la regex sont injectes dans le message via str.format.

Utilise uniquement l'analyse textuelle du longrepr + outcome. Pas de LLM,
pas de requete reseau, pas de donnees utilisateur envoyees nulle part.
"""

from __future__ import annotations

import re
from dataclasses import dataclass
from typing import Callable


@dataclass
class Diagnosis:
    kind: str  # 'assertion', 'network', 'fixture', 'import', ...
    message: str  # Message final traduit


# Format : (pattern, kind, template_key)
# template_key est la cle gettext, `{0}`, `{1}` ... capturent les groupes
RULES: list[tuple[re.Pattern, str, str]] = [
    # --- Assertions pytest standard ---
    (
        re.compile(r"AssertionError:\s*assert\s+(.+?)\s*==\s*(.+)"),
        "assertion_equality",
        "diag.assertion_equality",
    ),
    (
        re.compile(r"AssertionError:\s*assert\s+(\d+)\s*>\s*(\d+)"),
        "assertion_comparison",
        "diag.assertion_comparison",
    ),
    (
        re.compile(r"AssertionError:\s*assert\s+(False|None|0|'')"),
        "assertion_falsy",
        "diag.assertion_falsy",
    ),
    (re.compile(r"AssertionError\b"), "assertion", "diag.assertion_generic"),
    # --- Reseau / I/O ---
    (
        re.compile(r"ConnectionRefusedError|ConnectionError:\s*(.+)"),
        "network",
        "diag.connection_refused",
    ),
    (
        re.compile(
            r"(TimeoutError|asyncio\.TimeoutError|requests\.exceptions\.Timeout)"
        ),
        "timeout",
        "diag.timeout",
    ),
    (
        re.compile(r"socket\.(gaierror|timeout)"),
        "network",
        "diag.dns_issue",
    ),
    (
        re.compile(r"urllib\.error\.URLError"),
        "network",
        "diag.url_error",
    ),
    # --- Fixture pytest ---
    (
        re.compile(r"fixture '(.+?)' not found"),
        "fixture",
        "diag.fixture_not_found",
    ),
    (
        re.compile(r"ScopeMismatch:"),
        "fixture",
        "diag.fixture_scope_mismatch",
    ),
    # --- Import / AttributeError ---
    (
        re.compile(r"ModuleNotFoundError:\s*No module named '(.+?)'"),
        "import",
        "diag.module_not_found",
    ),
    (
        re.compile(r"ImportError:\s*cannot import name '(.+?)' from '(.+?)'"),
        "import",
        "diag.cannot_import_name",
    ),
    (
        re.compile(r"AttributeError:\s*'(.+?)' object has no attribute '(.+?)'"),
        "attribute",
        "diag.attribute_missing",
    ),
    # --- Types / valeurs ---
    (
        re.compile(r"TypeError:\s*(.+?) takes (\d+) positional arguments but (\d+)"),
        "signature",
        "diag.signature_mismatch",
    ),
    (
        re.compile(r"TypeError:\s*unsupported operand type\(s\) for (.+?):"),
        "type",
        "diag.unsupported_operand",
    ),
    (
        re.compile(r"ValueError:\s*(.+)"),
        "value",
        "diag.value_error",
    ),
    (
        re.compile(r"KeyError:\s*'?(.+?)'?$"),
        "key",
        "diag.key_error",
    ),
    (
        re.compile(r"IndexError:\s*(.+)"),
        "index",
        "diag.index_error",
    ),
    (
        re.compile(r"ZeroDivisionError"),
        "division",
        "diag.zero_division",
    ),
    # --- Fichiers / permissions ---
    (
        re.compile(r"FileNotFoundError:.*'(.+?)'"),
        "file",
        "diag.file_not_found",
    ),
    (
        re.compile(r"PermissionError:"),
        "file",
        "diag.permission_denied",
    ),
    (
        re.compile(r"IsADirectoryError:"),
        "file",
        "diag.is_a_directory",
    ),
    # --- Playwright / Selenium (QA) ---
    (
        re.compile(r"playwright\..*?Error.*?Timeout.*?exceeded"),
        "playwright",
        "diag.playwright_timeout",
    ),
    (
        re.compile(r"playwright\..*?Error.*?intercepted"),
        "playwright",
        "diag.playwright_intercepted",
    ),
    (
        re.compile(r"selenium\.common\.exceptions\.NoSuchElementException"),
        "selenium",
        "diag.selenium_no_element",
    ),
    (
        re.compile(r"selenium\.common\.exceptions\.StaleElementReferenceException"),
        "selenium",
        "diag.selenium_stale_element",
    ),
    # --- Async / concurrence ---
    (
        re.compile(r"RuntimeError:.*?event loop"),
        "async",
        "diag.event_loop",
    ),
    (
        re.compile(r"coroutine.*was never awaited", re.DOTALL),
        "async",
        "diag.missing_await",
    ),
    # --- Syntaxe (collection error) ---
    (
        re.compile(r"SyntaxError:\s*(.+)"),
        "syntax",
        "diag.syntax_error",
    ),
    (
        re.compile(r"IndentationError:\s*(.+)"),
        "syntax",
        "diag.indentation_error",
    ),
    # --- Pytest internal ---
    (
        re.compile(r"collection error"),
        "collection",
        "diag.collection_error",
    ),
    (
        re.compile(r"xfail.*strict.*xfailed"),
        "xfail",
        "diag.strict_xfail",
    ),
]


def diagnose(longrepr: str, t: Callable[[str], str] | None = None) -> Diagnosis | None:
    """Analyse un traceback et retourne un diagnostic, ou None si aucun match."""
    if not longrepr:
        return None
    if t is None:
        t = lambda s: s  # noqa: E731

    for pattern, kind, template_key in RULES:
        m = pattern.search(longrepr)
        if not m:
            continue
        template = t(template_key)
        if template == template_key:
            # Pas de traduction -> fallback anglais
            template = _FALLBACK_EN.get(template_key, template_key)
        try:
            message = template.format(*m.groups())
        except (IndexError, KeyError):
            message = template
        return Diagnosis(kind=kind, message=message)

    return None


# Fallback anglais si la traduction n'est pas fournie dans le catalogue gettext
_FALLBACK_EN = {
    "diag.assertion_equality": "Equality assertion failed: {0} != {1}. Check the computation.",
    "diag.assertion_comparison": "Comparison {0} > {1} is false. Values swapped? Off-by-one?",
    "diag.assertion_falsy": "Value {0} is falsy. Expected a truthy value.",
    "diag.assertion_generic": "Assertion failed. Use pytest -vv for detailed diff.",
    "diag.connection_refused": "Connection refused ({0}). Is the target service running on the expected port?",
    "diag.timeout": "Operation timed out. Increase the timeout or check for a missing await.",
    "diag.dns_issue": "DNS resolution failed. Check network / DNS / hosts file.",
    "diag.url_error": "URL unreachable. Network or proxy issue.",
    "diag.fixture_not_found": "Fixture '{0}' not found. Is it declared in conftest.py or an imported module?",
    "diag.fixture_scope_mismatch": "Fixture scope mismatch. A finer-scoped fixture is used by a broader one.",
    "diag.module_not_found": "Module '{0}' not installed. Run: pip install {0}",
    "diag.cannot_import_name": "Cannot import '{0}' from '{1}'. Typo or recent refactor?",
    "diag.attribute_missing": "'{0}' has no attribute '{1}'. Typo, API change, or missing assignment?",
    "diag.signature_mismatch": "Signature mismatch on {0}: expected {1} args, got {2}.",
    "diag.unsupported_operand": "Unsupported operand for {0}. Types don't match (e.g. str + int).",
    "diag.value_error": "ValueError: {0}. Validation rule violated.",
    "diag.key_error": "Missing key '{0}' in dict. Did you init the key or mistype?",
    "diag.index_error": "Index out of range: {0}. Off-by-one or empty list?",
    "diag.zero_division": "Division by zero. Add a guard or default.",
    "diag.file_not_found": "File not found: '{0}'. Wrong path or missing fixture?",
    "diag.permission_denied": "Permission denied. Check file ownership or run as elevated user.",
    "diag.is_a_directory": "Expected a file, got a directory.",
    "diag.playwright_timeout": "Playwright timeout. Page didn't load or element never appeared. Increase timeout.",
    "diag.playwright_intercepted": "Playwright click intercepted. Element is covered (cookie banner, overlay?).",
    "diag.selenium_no_element": "Selenium: element not found. Check selector or wait for the element.",
    "diag.selenium_stale_element": "Stale element. DOM changed between find and action. Re-query the element.",
    "diag.event_loop": "Event loop error. No loop running or loop closed. Use pytest-asyncio properly.",
    "diag.missing_await": "A coroutine was never awaited. Add `await` or use `pytest.mark.asyncio`.",
    "diag.syntax_error": "Syntax error: {0}. Parse failure, test not collected.",
    "diag.indentation_error": "Indentation error: {0}. Tabs/spaces mix?",
    "diag.collection_error": "Collection error. Check import errors above.",
    "diag.strict_xfail": "Test marked strict xfail but passed. Remove the xfail marker.",
}
