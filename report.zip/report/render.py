"""Generation du HTML final a partir de ReportData + catalog de traduction."""

from __future__ import annotations

import html
import re
from typing import Callable

from .css import CSS
from .data import ReportData, TestRecord
from .diagnosis import diagnose
from .donut import render_donut
from .history import diff_vs_previous, flaky_score, load_history
from .js import JS
from .notes import load_notes
from .screenshots import encode_as_data_uri, find_screenshots, match_screenshots
from .themes import render_theme_css
from .timeline import render_timeline


OUTCOMES_ORDER = ("failed", "error", "passed", "skipped", "xfailed", "xpassed")
OUTCOME_COLORS = {
    "passed": "#22c55e",
    "failed": "#ef4444",
    "error": "#f97316",
    "skipped": "#f59e0b",
    "xfailed": "#a855f7",
    "xpassed": "#06b6d4",
}


def _format_duration(seconds: float) -> str:
    if seconds < 0:
        seconds = 0
    if seconds < 0.001:
        return f"{seconds * 1_000_000:.0f} us"
    if seconds < 1:
        return f"{seconds * 1000:.0f} ms"
    if seconds < 60:
        return f"{seconds:.2f} s"
    mins = int(seconds // 60)
    secs = seconds - mins * 60
    return f"{mins}m {secs:.1f}s"


def _format_nodeid(nodeid: str) -> str:
    if "::" not in nodeid:
        return f'<span class="file">{html.escape(nodeid)}</span>'
    file, *rest = nodeid.split("::")
    parts = [f'<span class="file">{html.escape(file)}</span>']
    for part in rest:
        parts.append('<span class="sep">::</span>')
        parts.append(f'<span class="test-name">{html.escape(part)}</span>')
    return "".join(parts)


def _render_test(
    r: TestRecord,
    t: Callable[[str], str],
    note: dict | None = None,
    flaky: float | None = None,
    screenshots: list | None = None,
) -> str:
    badge = html.escape(t(r.outcome.upper()) or r.outcome.upper())
    duration = _format_duration(r.duration)
    nodeid_html = _format_nodeid(r.nodeid)

    sections = []

    # Diagnosis offline (si echec et traceback match une regle)
    if r.outcome in ("failed", "error") and r.longrepr:
        diag = diagnose(r.longrepr, t)
        if diag is not None:
            sections.append(
                f'<div class="section diagnosis">'
                f"<h4>{html.escape(t('diagnosis'))}</h4>"
                f'<div class="diag-body">'
                f'<span class="diag-kind">{html.escape(diag.kind)}</span>'
                f'<span class="diag-message">{html.escape(diag.message)}</span>'
                f"</div></div>"
            )

    # Note persistee pour ce nodeid
    if note:
        sections.append(
            f'<div class="section note">'
            f"<h4>{html.escape(t('note'))}</h4>"
            f'<div class="note-meta mono">{html.escape(note.get("updated", ""))}</div>'
            f'<div class="note-text">{html.escape(note.get("note", ""))}</div>'
            f"</div>"
        )

    if r.longrepr:
        sections.append(
            f'<div class="section"><h4>{html.escape(t("traceback"))}</h4>'
            f'<pre class="smart-trace">{_highlight_longrepr(r.longrepr)}</pre></div>'
        )
    if r.captured_stdout:
        sections.append(
            f'<div class="section"><h4>{html.escape(t("captured stdout"))}</h4>'
            f"<pre>{html.escape(r.captured_stdout)}</pre></div>"
        )
    if r.captured_stderr:
        sections.append(
            f'<div class="section"><h4>{html.escape(t("captured stderr"))}</h4>'
            f"<pre>{html.escape(r.captured_stderr)}</pre></div>"
        )
    if r.captured_log:
        sections.append(
            f'<div class="section"><h4>{html.escape(t("captured log"))}</h4>'
            f"<pre>{html.escape(r.captured_log)}</pre></div>"
        )
    if r.markers:
        tags = "".join(
            f'<span class="marker">@{html.escape(m)}</span>' for m in r.markers
        )
        sections.append(f'<div class="section"><div class="markers">{tags}</div></div>')

    # Screenshots attaches
    if screenshots:
        imgs = "".join(
            f'<a href="{encode_as_data_uri(p)}" download="{html.escape(p.name)}" '
            f'target="_blank" class="shot-link">'
            f'<img src="{encode_as_data_uri(p)}" alt="{html.escape(p.name)}" />'
            f'<span class="shot-name">{html.escape(p.name)}</span>'
            f"</a>"
            for p in screenshots
        )
        sections.append(
            f'<div class="section"><h4>{html.escape(t("screenshots"))}</h4>'
            f'<div class="shots">{imgs}</div></div>'
        )

    body = f'<div class="test-body">{"".join(sections)}</div>' if sections else ""

    # Badge supplementaire si note presente
    note_indicator = ""
    if note:
        note_indicator = f'<span class="note-indicator" title="{html.escape(t("note"))}">&#128172;</span>'

    # Badge flaky si historique montre une instabilite
    flaky_indicator = ""
    if flaky is not None and flaky > 0:
        pct = int(flaky * 100)
        flaky_indicator = (
            f'<span class="flaky-indicator" '
            f'title="{html.escape(t("flaky"))} ({pct}%)">&#10071;</span>'
        )

    # Ancre stable pour permalink
    anchor = "t-" + re.sub(r"[^a-zA-Z0-9]+", "-", r.nodeid).strip("-")

    return (
        f'<div class="test" id="{anchor}" data-outcome="{html.escape(r.outcome)}" '
        f'data-nodeid="{html.escape(r.nodeid.lower())}">'
        f'<div class="test-header">'
        f'<span class="chevron">&#9654;</span>'
        f'<span class="badge">{badge}</span>'
        f'<span class="nodeid mono">{nodeid_html}</span>'
        f"{flaky_indicator}"
        f"{note_indicator}"
        f'<a href="#{anchor}" class="permalink-btn" title="{html.escape(t("copy link"))}" '
        f"onclick=\"event.stopPropagation();navigator.clipboard.writeText(location.href.split('#')[0]+'#{anchor}')\">&#128279;</a>"
        f'<span class="duration mono">{duration}</span>'
        f"</div>"
        f"{body}"
        f"</div>"
    )


def _render_sidebar(data: ReportData, t: Callable[[str], str]) -> str:
    counts = data.counts
    # Sections du sidebar : cliquables qui scroll vers l'ancre
    nav_items = [
        ("#overview", "overview", data.total),
        ("#tests", "tests", data.total),
    ]
    # Une entree de nav par outcome present (compte > 0), filtre dans la liste
    outcome_items = []
    for outcome in OUTCOMES_ORDER:
        n = counts.get(outcome, 0)
        if n > 0:
            outcome_items.append((f'javascript:filterOnly("{outcome}")', outcome, n))

    def nav_link(href, label_key, count, active=False):
        cls = ' class="active"' if active else ""
        return (
            f'<li><a href="{href}"{cls}>'
            f"<span>{html.escape(t(label_key))}</span>"
            f'<span class="nav-count">{count}</span>'
            f"</a></li>"
        )

    nav_main = "".join(
        nav_link(href, key, c, active=(i == 0))
        for i, (href, key, c) in enumerate(nav_items)
    )
    nav_outcomes = "".join(nav_link(href, key, c) for href, key, c in outcome_items)

    theme_selector = (
        f'<div class="theme-selector">'
        f'  <select id="theme-select" aria-label="{html.escape(t("theme"))}">'
        f'    <option value="auto">{html.escape(t("theme auto"))}</option>'
        f'    <option value="light">{html.escape(t("theme light"))}</option>'
        f'    <option value="dark">{html.escape(t("theme dark"))}</option>'
        f'    <option value="dracula">Dracula</option>'
        f'    <option value="solarized">Solarized</option>'
        f'    <option value="high-contrast">{html.escape(t("theme contrast"))}</option>'
        f"  </select>"
        f"</div>"
    )
    return (
        f'<aside class="sidebar">'
        f'  <div class="sidebar-brand">'
        f"    <h1>pytest-translate</h1>"
        f'    <span class="tagline">'
        f"{html.escape(t('test report'))}</span>"
        f"  </div>"
        f'  <div class="sidebar-section-title">{html.escape(t("navigation"))}</div>'
        f'  <ul class="sidebar-nav">{nav_main}</ul>'
        f'  <div class="sidebar-section-title">{html.escape(t("outcomes"))}</div>'
        f'  <ul class="sidebar-nav">{nav_outcomes}</ul>'
        f'  <div class="sidebar-section-title">{html.escape(t("theme"))}</div>'
        f"  {theme_selector}"
        f"</aside>"
    )


def _render_donut_overview(data: ReportData, t: Callable[[str], str]) -> str:
    counts = data.counts
    segments = []
    for outcome in OUTCOMES_ORDER:
        n = counts.get(outcome, 0)
        if n > 0:
            segments.append((outcome, n, OUTCOME_COLORS[outcome]))

    donut = render_donut(segments, size=180)

    # Legend cliquable (filtre identique aux stat cards)
    legend_items = []
    for outcome, n, color in segments:
        legend_items.append(
            f'<div class="legend-item" data-outcome="{outcome}">'
            f'<span class="legend-dot" style="background:{color}"></span>'
            f'<span class="legend-label">{html.escape(t(outcome))}</span>'
            f'<span class="legend-value">{n}</span>'
            f"</div>"
        )
    if not legend_items:
        legend_items.append(
            f'<div class="empty">{html.escape(t("no tests ran"))}</div>'
        )
    legend_html = "".join(legend_items)

    return (
        f'<section class="overview" id="overview">'
        f'  <div class="donut-wrap">'
        f"    {donut}"
        f'    <div class="donut-center">'
        f'      <div class="big">{data.success_rate:.0f}%</div>'
        f'      <div class="label">{html.escape(t("success rate"))}</div>'
        f"    </div>"
        f"  </div>"
        f'  <div class="legend">{legend_html}</div>'
        f"</section>"
    )


def _render_tiles(data: ReportData, t: Callable[[str], str]) -> str:
    counts = data.counts
    failed_total = counts.get("failed", 0) + counts.get("error", 0)
    tiles = [
        (data.total, "tests", False),
        (_format_duration(data.duration), "duration", False),
        (failed_total, "failures", failed_total > 0),
        (counts.get("skipped", 0), "skipped", False),
    ]
    out = []
    for value, key, is_bad in tiles:
        cls = "tile accent" if not is_bad else "tile"
        color_style = ' style="color:var(--c-failed)"' if is_bad else ""
        out.append(
            f'<div class="{cls}">'
            f'<div class="tile-value"{color_style}>{value}</div>'
            f'<div class="tile-label">{html.escape(t(key))}</div>'
            f"</div>"
        )
    return f'<div class="tiles">{"".join(out)}</div>'


def _render_diff_panel(
    data: ReportData, history: list[dict], t: Callable[[str], str]
) -> str:
    if not history:
        return ""
    diff = diff_vs_previous(data, history)
    new_f = diff["new_failures"]
    fixed = diff["fixed"]
    still = diff["still_failing"]
    new_t = diff["new_tests"]
    removed = diff["removed_tests"]
    if not any([new_f, fixed, still, new_t, removed]):
        return ""

    parts = []
    if new_f:
        parts.append(
            f'<div class="diff-item diff-regress">'
            f'<span class="diff-badge">{html.escape(t("new failures"))}</span>'
            f'<span class="diff-count">{len(new_f)}</span>'
            f'<ul class="diff-list">'
            + "".join(f"<li>{html.escape(n)}</li>" for n in new_f[:5])
            + (
                f"<li>... +{len(new_f) - 5} {html.escape(t('more'))}</li>"
                if len(new_f) > 5
                else ""
            )
            + "</ul></div>"
        )
    if fixed:
        parts.append(
            f'<div class="diff-item diff-fixed">'
            f'<span class="diff-badge">{html.escape(t("fixed"))}</span>'
            f'<span class="diff-count">{len(fixed)}</span>'
            f'<ul class="diff-list">'
            + "".join(f"<li>{html.escape(n)}</li>" for n in fixed[:5])
            + "</ul></div>"
        )
    if still:
        parts.append(
            f'<div class="diff-item diff-still">'
            f'<span class="diff-badge">{html.escape(t("still failing"))}</span>'
            f'<span class="diff-count">{len(still)}</span>'
            f"</div>"
        )
    if new_t:
        parts.append(
            f'<div class="diff-item diff-new">'
            f'<span class="diff-badge">{html.escape(t("new tests"))}</span>'
            f'<span class="diff-count">{len(new_t)}</span>'
            f"</div>"
        )
    if removed:
        parts.append(
            f'<div class="diff-item diff-removed">'
            f'<span class="diff-badge">{html.escape(t("removed tests"))}</span>'
            f'<span class="diff-count">{len(removed)}</span>'
            f"</div>"
        )

    return (
        f'<section class="diff-panel">'
        f"<h3>{html.escape(t('changes vs previous run'))}</h3>"
        f'<div class="diff-grid">{"".join(parts)}</div>'
        f"</section>"
    )


def _render_history_sparkline(history: list[dict], t: Callable[[str], str]) -> str:
    if len(history) < 2:
        return ""
    # Affiche les N derniers runs comme mini barres (succes rate)
    runs = list(reversed(history[:15]))  # chrono croissant
    max_total = max((r.get("total", 0) for r in runs), default=1) or 1
    bars = []
    for r in runs:
        total = r.get("total", 0)
        counts = r.get("counts", {})
        passed = counts.get("passed", 0) + counts.get("xpassed", 0)
        failed = counts.get("failed", 0) + counts.get("error", 0)
        skipped = total - passed - failed
        h_total = 40 * (total / max_total) if max_total else 0
        h_passed = h_total * (passed / total) if total else 0
        h_failed = h_total * (failed / total) if total else 0
        h_skipped = h_total * (skipped / total) if total else 0
        ts = r.get("timestamp", "")
        title = f"{ts} - {total} tests ({passed} ok, {failed} KO)"
        bars.append(
            f'<div class="spark-bar" title="{html.escape(title)}">'
            f'<span style="background:var(--c-passed);height:{h_passed:.1f}px"></span>'
            f'<span style="background:var(--c-skipped);height:{h_skipped:.1f}px"></span>'
            f'<span style="background:var(--c-failed);height:{h_failed:.1f}px"></span>'
            f"</div>"
        )
    return (
        f'<section class="history-panel">'
        f'<h3>{html.escape(t("history"))} <span class="subtitle">({len(runs)} {html.escape(t("runs"))})</span></h3>'
        f'<div class="spark-bars">{"".join(bars)}</div>'
        f"</section>"
    )


def _render_timeline_panel(data: ReportData, t: Callable[[str], str]) -> str:
    svg = render_timeline(data)
    if not svg:
        return ""
    return (
        f'<section class="timeline-panel">'
        f"<h3>{html.escape(t('timeline'))}</h3>"
        f'<div class="timeline-chart">{svg}</div>'
        f"</section>"
    )


def _render_exec_summary(data: ReportData, t: Callable[[str], str]) -> str:
    """Panel PM-friendly : 2-3 lignes lisibles par un non-tech."""
    counts = data.counts
    passed = counts.get("passed", 0) + counts.get("xpassed", 0)
    failed = counts.get("failed", 0) + counts.get("error", 0)
    skipped = counts.get("skipped", 0)

    status = "ok" if failed == 0 else "alert"
    status_label = t("all green") if failed == 0 else t("action required")

    lines = []
    if failed > 0:
        lines.append(f"{failed} {t('tests failing')}")
    if passed > 0:
        lines.append(f"{passed} {t('tests passing')}")
    if skipped > 0:
        lines.append(f"{skipped} {t('tests skipped')}")
    summary = " - ".join(lines)

    return (
        f'<details class="exec-summary exec-{status}" open>'
        f"<summary>"
        f'<span class="exec-badge exec-{status}-badge">'
        f"{html.escape(status_label)}</span>"
        f'<span class="exec-main">{html.escape(summary)}</span>'
        f"</summary>"
        f'<div class="exec-body">'
        f"<p>{html.escape(t('exec summary body'))}</p>"
        f"</div>"
        f"</details>"
    )


def _highlight_longrepr(longrepr: str) -> str:
    """Smart stacktrace : souligne les lignes user (vs framework)."""
    out_lines = []
    for line in longrepr.splitlines():
        stripped = line.strip()
        escaped = html.escape(line)
        # Lignes venant du code user (pas dans site-packages ni stdlib)
        is_framework = (
            "site-packages" in line
            or "/lib/python" in line
            or "_pytest" in line
            or stripped.startswith('File "/usr/')
        )
        # Lignes d'assertion E (pytest prefix pour erreurs)
        is_error_line = stripped.startswith("E ")
        if is_error_line:
            out_lines.append(f'<span class="line line-error">{escaped}</span>')
        elif not is_framework and line.strip():
            out_lines.append(f'<span class="line line-user">{escaped}</span>')
        else:
            out_lines.append(f'<span class="line line-fw">{escaped}</span>')
    return "\n".join(out_lines)


def _render_meta(data: ReportData, t: Callable[[str], str]) -> str:
    rows = [
        ("root_directory", data.rootdir, t("root_directory")),
        (None, data.python_version, "Python"),
        (None, data.pytest_version, "pytest"),
        (None, data.plugin_version, "pytest-translate"),
        ("platform_label", data.platform, t("platform_label")),
    ]
    cells = []
    for _key, val, label in rows:
        if not val:
            continue
        cells.append(
            f'<div><span class="meta-key">{html.escape(label)}:</span> '
            f'<span class="meta-val mono">{html.escape(val)}</span></div>'
        )
    return f'<div class="meta">{"".join(cells)}</div>'


def render_html(
    data: ReportData,
    t: Callable[[str], str] | None = None,
    auto_open_failed: bool = True,
) -> str:
    if t is None:
        t = lambda s: s  # noqa: E731

    title = html.escape(t("test report"))
    auto_open = "1" if auto_open_failed else "0"

    outcome_rank = {
        "error": 0,
        "failed": 1,
        "xpassed": 2,
        "xfailed": 3,
        "skipped": 4,
        "passed": 5,
    }
    records = sorted(
        data.records, key=lambda r: (outcome_rank.get(r.outcome, 99), r.nodeid)
    )

    # Historique (chargement silencieux si absent)
    try:
        history = load_history()
    except Exception:
        history = []
    try:
        notes_by_nodeid = load_notes()
    except Exception:
        notes_by_nodeid = {}
    try:
        flaky_by_nodeid = flaky_score(history)
    except Exception:
        flaky_by_nodeid = {}
    try:
        all_shots = find_screenshots().get("_all", [])
        shots_by_nodeid = match_screenshots(records, all_shots)
    except Exception:
        shots_by_nodeid = {}

    tests_html = "".join(
        _render_test(
            r,
            t,
            note=notes_by_nodeid.get(r.nodeid),
            flaky=flaky_by_nodeid.get(r.nodeid),
            screenshots=shots_by_nodeid.get(r.nodeid),
        )
        for r in records
    )
    if not tests_html:
        tests_html = f'<div class="empty">{html.escape(t("no tests ran"))}</div>'

    empty_filter = (
        f'<div class="empty empty-filter" style="display:none">'
        f"{html.escape(t('no tests match filters'))}"
        f"</div>"
    )

    sidebar = _render_sidebar(data, t)
    overview = _render_donut_overview(data, t)
    tiles = _render_tiles(data, t)
    meta = _render_meta(data, t)
    diff_panel = _render_diff_panel(data, history, t)
    history_panel = _render_history_sparkline(history, t)
    timeline_panel = _render_timeline_panel(data, t)
    exec_summary = _render_exec_summary(data, t)

    theme_css = render_theme_css()

    return f"""<!doctype html>
<html lang="{html.escape(data.lang)}">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>{title}</title>
<style>{CSS}
{theme_css}
</style>
</head>
<body data-auto-open-failed="{auto_open}">
<div class="layout">
  {sidebar}
  <main class="main">
    <header class="page-header">
      <h2>{title}</h2>
      <div class="subtitle">{html.escape(t("Generated by pytest-translate"))}</div>
    </header>
    {exec_summary}
    {meta}
    {overview}
    {tiles}
    {diff_panel}
    {history_panel}
    {timeline_panel}
    <div class="section-title" id="tests">
      <h3>{html.escape(t("tests"))} <span class="subtitle">(<span data-visible-counter>{data.total}</span>/{data.total})</span></h3>
    </div>
    <div class="controls">
      <input type="text" id="search" class="search" placeholder="{html.escape(t("search nodeid"))}" aria-label="search">
      <button type="button" class="control-btn" id="expand-all">{html.escape(t("expand all"))}</button>
      <button type="button" class="control-btn" id="collapse-all">{html.escape(t("collapse all"))}</button>
    </div>
    <div class="tests">
      {tests_html}
      {empty_filter}
    </div>
    <footer>
      pytest-translate &bull; {data.plugin_version or "v2"}
    </footer>
  </main>
</div>
<script>{JS}</script>
</body>
</html>
"""
