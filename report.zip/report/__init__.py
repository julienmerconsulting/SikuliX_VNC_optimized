"""Reporter HTML natif de pytest-translate."""

from .data import ReportData, TestRecord
from .render import render_html

__all__ = ["ReportData", "TestRecord", "render_html"]
