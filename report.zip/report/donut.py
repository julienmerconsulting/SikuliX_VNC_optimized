"""Generation d'un donut chart SVG sans dep. Pur Python."""

from __future__ import annotations

import math


def _arc_path(cx: float, cy: float, r: float, start_deg: float, end_deg: float) -> str:
    """Genere un path SVG pour un arc de cercle."""
    start = math.radians(start_deg)
    end = math.radians(end_deg)
    x1 = cx + r * math.cos(start)
    y1 = cy + r * math.sin(start)
    x2 = cx + r * math.cos(end)
    y2 = cy + r * math.sin(end)
    large_arc = 1 if (end_deg - start_deg) > 180 else 0
    return f"M {cx} {cy} L {x1} {y1} A {r} {r} 0 {large_arc} 1 {x2} {y2} Z"


def render_donut(
    segments: list[tuple[str, int, str]],
    size: int = 180,
    hole_ratio: float = 0.6,
) -> str:
    """
    Genere un donut chart SVG a partir d'une liste de (label, value, color).

    - On utilise la propriete stroke-dasharray sur un cercle pour creer les segments
      (pas de path trigonometrique, beaucoup plus simple et performant).
    - Les segments de valeur 0 sont ignores.
    - Retourne un string SVG prete a inliner.
    """
    total = sum(v for _, v, _ in segments)
    cx = cy = size / 2
    r = (size / 2) * hole_ratio + (size / 2 - size / 2 * hole_ratio) / 2
    # r = rayon du cercle, stroke-width = epaisseur
    stroke_w = (size / 2) - (size / 2 * hole_ratio)
    circumference = 2 * math.pi * r

    if total == 0:
        # Cercle vide stylise
        return (
            f'<svg viewBox="0 0 {size} {size}">'
            f'<circle cx="{cx}" cy="{cy}" r="{r}" stroke="currentColor" '
            f'stroke-width="{stroke_w}" style="opacity:0.15"></circle>'
            f"</svg>"
        )

    circles = []
    offset = 0.0
    for _label, value, color in segments:
        if value <= 0:
            continue
        fraction = value / total
        dash = fraction * circumference
        gap = circumference - dash
        circles.append(
            f'<circle cx="{cx}" cy="{cy}" r="{r}" stroke="{color}" '
            f'stroke-width="{stroke_w}" '
            f'stroke-dasharray="{dash:.3f} {gap:.3f}" '
            f'stroke-dashoffset="{-offset:.3f}"></circle>'
        )
        offset += dash

    circles_svg = "\n".join(circles)
    return (
        f'<svg viewBox="0 0 {size} {size}" role="img" aria-label="outcomes donut chart">'
        f"{circles_svg}"
        f"</svg>"
    )
