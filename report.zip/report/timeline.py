"""
Timeline Gantt : rendu SVG des tests sur un axe temporel.

Utile pour visualiser :
- L'ordre d'execution
- Les tests qui prennent longtemps (detection des lents en un coup d'oeil)
- Les runs paralleles (pytest-xdist) si start/stop per test disponibles

SVG inline, zero dep. Largeur responsive via viewBox.
"""

from __future__ import annotations

import html

from .data import ReportData


OUTCOME_COLORS_TL = {
    "passed": "#22c55e",
    "failed": "#ef4444",
    "error": "#f97316",
    "skipped": "#f59e0b",
    "xfailed": "#a855f7",
    "xpassed": "#06b6d4",
}


def render_timeline(data: ReportData) -> str:
    """Genere un SVG Gantt des tests. Retourne "" si donnees insuffisantes."""
    records = [r for r in data.records if r.start_time and r.end_time]
    if not records or data.duration <= 0:
        return ""

    # Echelle temporelle sur la duree totale
    total_dur = data.duration
    if total_dur <= 0:
        return ""

    width = 1000
    bar_h = 14
    bar_gap = 3
    height = len(records) * (bar_h + bar_gap) + 40

    rows = []
    for i, r in enumerate(sorted(records, key=lambda x: x.start_time)):
        x = (r.start_time - data.started_at) / total_dur * width
        w = max(1, (r.end_time - r.start_time) / total_dur * width)
        y = 20 + i * (bar_h + bar_gap)
        color = OUTCOME_COLORS_TL.get(r.outcome, "#64748b")
        title = f"{r.nodeid} - {r.outcome} - {r.duration:.3f}s"
        rows.append(
            f'<rect x="{x:.1f}" y="{y}" width="{w:.1f}" height="{bar_h}" '
            f'fill="{color}" rx="2">'
            f"<title>{html.escape(title)}</title>"
            f"</rect>"
        )

    # Ticks d'axe en bas (4 reperes reguliers)
    ticks = []
    for i in range(5):
        t = total_dur * i / 4
        x = width * i / 4
        ticks.append(
            f'<line x1="{x}" y1="10" x2="{x}" y2="{height - 10}" '
            f'stroke="currentColor" stroke-opacity="0.1" stroke-dasharray="2,3"/>'
        )
        ticks.append(
            f'<text x="{x}" y="{height - 2}" text-anchor="middle" '
            f'font-size="9" fill="currentColor" opacity="0.6">{t:.2f}s</text>'
        )

    return (
        f'<svg viewBox="0 0 {width} {height}" '
        f'xmlns="http://www.w3.org/2000/svg" '
        f'style="width:100%;height:auto;">'
        f"{''.join(ticks)}"
        f"{''.join(rows)}"
        f"</svg>"
    )
